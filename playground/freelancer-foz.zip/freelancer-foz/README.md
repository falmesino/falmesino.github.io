# freelancer-ftc
Website for FOZ. A project from Freelancer

Created by Falmesino (@falmesino)

## Installation

Just put the files in your webroot.

## Notes

- Please do not modify the `css/style.css` file directly, use `custom.css` to override existing classes instead.
- Or if you know SASS, please do the modification in `scss` folder and compile the `main.scss` into `style.css`